<footer>
    <div id="f-top" class="row" align="center">
            <div class="span2"><i class="circle btn-info fa fa-facebook"></i></div>
            <div class="span3"><i class="circle btn-primary fa fa-twitter"></i></div>
            <div class="span3"><i class="circle btn-danger fa fa-google-plus-official"></i></div>
            <div class="span2"><i class="circle btn-primary fa fa-linkedin""></i></div>
            <div class="span2"><i class="circle btn-danger fa fa-youtube-play""></i></div>
    </div>
    <div id="f-bottom" align="center">
        <p>Truth Shall Prevail</p>
    </div>
</footer>