<div class="navbar">
    <div class="navbar-inner">
        <div class="container" id="header">
			<div id="top-header" class="row" align="center" style="margin:0px">
				<a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse">
					<span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span>
				</a>
				<a class="brand" href="index.php"><img src="img/CMMS-Logo.png" /></a>
				<h1 style="color:#750202;">CENTER FOR MEN AND MASCULINITIES STUDIES</h1>
			</div>
            <div class="row nav-collapse" style="font-weight:bold;background-color:	#bfaada; margin:0px">
                <ul class="nav pull-left">
                    <li><a href="index.php">Home</a></li>
                    <li><a class="navList" href="ourWork.php">Our Work</a></li>
                    <li><a  class="navList" href="news.php">News</a></li>
                    <li><a  class="navList" href="publications.php">Publications</a></li>
                    <li><a  class="navList" href="features.php">Features</a></li>
                    <li><a  class="navList" href="publications.php">Blog</a></li>
                    <li><a  class="navList" href="publications.php">Apps</a></li>
                    <li><a  class="navList" href="ourTeam.php">Our Team</a></li>
                    <li><a  class="navList" href="aboutUs.php">About Us</a></li>
                    <li><a  class="navList" href="contact.php">Contact</a></li>
                </ul>
            </div>
        </div>
    </div>
</div>