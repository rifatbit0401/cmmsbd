<!DOCTYPE html>
<html lang="en">
<head>
    <title>CMMS</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="css/bootstrap.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <link href="css/bootstrap-responsive.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.6.3/css/font-awesome.min.css">
    <!--[if lt IE 9]>
    <script src="js/html5.js"></script><![endif]-->
    <link href='http://fonts.googleapis.com/css?family=Lato:300' rel='stylesheet' type='text/css'>
</head>
<body>
	<?php
		include "header.php";
	?>

<div class="container-fluid">
    <!--Start Carousel-->
    <div id="myCarousel" class="carousel slide">
        <div class="carousel-inner" align="center">
            <div class="item active"><img src="img/featured/1.jpg" alt=""></div>
            <div class="item"><img src="img/featured/2.jpg" alt=""></div>
            <div class="item"><img src="img/featured/10.jpg" alt=""></div>
        </div>
        <a class="left carousel-control" href="#myCarousel" data-slide="prev"><img src="img/arrow.png" alt=""></a> <a
                class="right carousel-control" href="#myCarousel" data-slide="next"><img src="img/arrow2.png"
                                                                                         alt=""></a></div>
    <!--End Carousel-->
    <hr>
    <div class="fontChange"></div>


    <div class="span6">
        <div style="width:100%;background-color:#e2b9e5">
            <h2>Features</h2>
        </div>
        <hr/>

        <img class="mySlides" , src="img/home/feature.PNG" , style="width:100%">
        <br/><br/><br/>
        <b style="font-size: 20px">The Campus Hero Cafe Orientation Course</b>
        <p class="text-justify" style="font-size: 18px; line-height: 200%">

            Center for Men and Mascuilinities Studies (CMMS) with 30 enthusiastic volunteers has successfully
            completed the 5 days Orientation Course of the Campus Hero Cafe. The residential event took place
            in Saint Martin's Island from December 19 to December 23, 2016. University students from different
            discipline went thorough
        </p>
        <a href="features.php" , style="font-size: 18px;color: black">Read More...</a>

    </div>


    <div class="span6">
        <div style="width:100%;background-color:#e2b9e5">
            <h2>Publications</h2>
        </div>
        <hr/>

        <div class="span2">
            <img src="img/home/pub2.PNG" height="200" width="175"/>
        </div>

        <div class="span3">
            <br/>
            <p class="text-justify" style="font-size: 18px; line-height: 150%">
                The self reflexive Brave Men Diary on SRHR is a tool design by the gender and sexuality experts
                comprising of five main chapter
            </p>
            <a href="publications/pdf/Brave Girl diary_English.pdf" style="font-size: 18px ">Read More...</a>
            <br/><br/><br/>
        </div>

        <div class="span2">
            <img src="img/home/pub3.PNG" height="200" width="175"/>
        </div>

        <div class="span3">
            <br/>
            <p class="text-justify" style="font-size: 18px; line-height: 150%">
                The self reflexive Brave Men Diary on SRHR is a tool design by the gender and sexuality experts
                comprising of five main chapter
            </p>
            <a href="publications/pdf/Brave Men Diary_Bangla.pdf" style="font-size: 18px ">Read More...</a>
            <br/><br/><br/>
        </div>

        <div class="span2 ">
            <img src="img/home/pub1.PNG" height="200" width="175"/>
        </div>

        <div class="span3">
            <br/>
            <p class="text-justify" style="font-size: 18px; line-height: 150%">
                The self reflexive Brave Men Diary on SRHR is a tool design by the gender and sexuality experts
                comprising of five main chapter
            </p>
            <a href="publications/pdf/Boys and Men Engagement to Reducing Gender Based Violence.pdf"
               style="font-size: 18px ">Read More...</a>
            <br/><br/><br/>
        </div>

    </div>


    <div class="span6">
        <div style="width:100%;background-color:#e2b9e5">
            <h2>Blog</h2>
        </div>
        <hr/>
        <div class="span2">
            <img src="img/home/blog1.PNG" height="200"/>
        </div>

        <div class="span3">
            <br/>
            <p class="text-justify" style="font-size: 18px; line-height: 150%">
                The self reflexive Brave Men Diary on SRHR is a tool design by the gender and sexuality experts
                comprising of five main chapter
            </p>
            <a href="" style="font-size: 18px ">Read More...</a>
            <br/><br/><br/>
        </div>

        <div class="span2">
            <img src="img/home/blog2.PNG" height="200"/>
        </div>

        <div class="span3">
            <br/>
            <p class="text-justify" style="font-size: 18px; line-height: 150%">
                The self reflexive Brave Men Diary on SRHR is a tool design by the gender and sexuality experts
                comprising of five main chapter
            </p>
            <a href="" style="font-size: 18px ">Read More...</a>
            <br/><br/><br/>
        </div>

        <div class="span2 ">
            <img src="img/home/blog3.PNG" height="200"/>
        </div>

        <div class="span3">
            <br/>
            <p class="text-justify" style="font-size: 18px; line-height: 150%">
                The self reflexive Brave Men Diary on SRHR is a tool design by the gender and sexuality experts
                comprising of five main chapter
            </p>
            <a href=""
               style="font-size: 18px ">Read More...</a>
            <br/><br/><br/>
        </div>

    </div>

    <div class="span6">
        <div style="width:100%;background-color:#e2b9e5">
            <h2>News</h2>
        </div>
        <hr/>
        <div>
            <div class="span2">
                <img src="img/home/news1.PNG" height="200"/>
            </div>

            <div class="span3">
                <br/>
                <p class="text-justify" style="font-size: 18px; line-height: 150%">
                    The self reflexive Brave Men Diary on SRHR is a tool design by the gender and sexuality experts
                    comprising of five main chapter
                </p>
                <a href="" style="font-size: 18px ">Read More...</a>
                <br/><br/><br/>
            </div>

            <div class="span2">
                <img src="img/home/news2.PNG" height="200"/>
            </div>

            <div class="span3">
                <br/>
                <p class="text-justify" style="font-size: 18px; line-height: 150%">
                    The self reflexive Brave Men Diary on SRHR is a tool design by the gender and sexuality experts
                    comprising of five main chapter
                </p>
                <a href="" style="font-size: 18px ">Read More...</a>
                <br/><br/><br/>
            </div>

            <div class="span2 ">
                <img src="img/home/news3.PNG" height="200"/>
            </div>

            <div class="span3">
                <br/>
                <p class="text-justify" style="font-size: 18px; line-height: 150%">
                    The self reflexive Brave Men Diary on SRHR is a tool design by the gender and sexuality experts
                    comprising of five main chapter
                </p>
                <a href=""
                   style="font-size: 18px ">Read More...</a>
                <br/><br/><br/>
            </div>
        </div>
    </div>
</div>

<?php include "footer.php"; ?>

<!-- /container -->
<script src="js/jquery-1.7.1.min.js"></script>
<script src="js/bootstrap-transition.js"></script>
<script src="js/bootstrap-carousel.js"></script>
<script src="js/bootstrap-alert.js"></script>
<script src="js/bootstrap-modal.js"></script>
<script src="js/bootstrap-dropdown.js"></script>
<script src="js/bootstrap-scrollspy.js"></script>
<script src="js/bootstrap-tab.js"></script>
<script src="js/bootstrap-tooltip.js"></script>
<script src="js/bootstrap-popover.js"></script>
<script src="js/bootstrap-button.js"></script>
<script src="js/bootstrap-collapse.js"></script>
<script src="js/bootstrap-typeahead.js"></script>
<script src="js/jquery-ui-1.8.18.custom.min.js"></script>
<script src="js/jquery.smooth-scroll.min.js"></script>
<script src="js/lightbox.js"></script>
<script>
    $('.carousel').carousel({
        interval: 3000
    })
</script>
</body>
</html>